/****************************************************/
/* File: util.c                                     */
/* Utility function implementation                  */
/* for the TINY compiler                            */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "util.h"

/* Procedure printToken prints a token 
 * and its lexeme to the listing file
 */

static char* expressionTypeStrings[]={"Void","Integer","Array"};
 
void printToken( TokenType token, const char* tokenString )
{
	switch (token)
	{
		case IF: fprintf(listing,"%-20s%-20s","IF",tokenString); 
			break;
		case ELSE: fprintf(listing,"%-20s%-20s","ELSE",tokenString); 
			break;
		case INT:	fprintf(listing,"%-20s%-20s","INT",tokenString); 
			break;
		case ID: fprintf(listing,"%-20s%-20s","ID",tokenString); 
			break;
		case NUM: fprintf(listing,"%-20s%-20s","NUM",tokenString); 
			break;
		case ASSIGN: fprintf(listing,"%-20s%-20s","ASSIGN",tokenString); 
			break;
		case EQ: fprintf(listing,"%-20s%-20s","==",tokenString); 
			break;
		case LT: fprintf(listing,"%-20s%-20s","<",tokenString); 
			break;
		case PLUS: fprintf(listing,"%-20s%-20s","+",tokenString); 
			break;
		case MINUS: fprintf(listing,"%-20s%-20s","-",tokenString); 
			break;
		case TIMES: fprintf(listing,"%-20s%-20s","*",tokenString); 
			break;
		case OVER: fprintf(listing,"%-20s%-20s","/",tokenString); 
			break;
		case LPAREN: fprintf(listing,"%-20s%-20s","(",tokenString); 
			break;
		case RPAREN: fprintf(listing,"%-20s%-20s",")",tokenString); 
			break;
		case SEMI: fprintf(listing,"%-20s%-20s",";",tokenString); 
			break;
		case COMMA: fprintf(listing,"%-20s%-20s","COMMA",tokenString); 
			break;
		case LEFTBRACE: fprintf(listing,"%-20s%-20s","{",tokenString); 
			break;
		case RIGHTBRACE: fprintf(listing,"%-20s%-20s","}",tokenString); 
			break;
		case LEFTBRACKET: fprintf(listing,"%-20s%-20s","[",tokenString); 
			break;
		case RIGHTBRACKET: fprintf(listing,"%-20s%-20s","]",tokenString); 
			break;	
		case RETURN: fprintf(listing,"%-20s%-20s","RETURN",tokenString); 
			break;
		case VOID: fprintf(listing,"%-20s%-20s","VOID",tokenString); 
			break;
		case WHILE: fprintf(listing,"%-20s%-20s","WHILE",tokenString); 
			break;
		case LESSTHANEQUAL: fprintf(listing,"%-20s%-20s","<=",tokenString); 
			break;
		case GREATERTHAN: fprintf(listing,"%-20s%-20s",">",tokenString); 
			break;
		case GREATERTHANEQUAL: fprintf(listing,"%-20s%-20s",">=",tokenString); 
			break;
		case NOTEQUAL: fprintf(listing,"%-20s%-20s","!=",tokenString); 
			break;
		case EOF:
		case ENDFILE: fprintf(listing,"%-20s","EOF"); 
			break;
		case ERROR: fprintf(listing,"%-20s%-20s","ERROR",tokenString); 
			break;
		case COMMENT_ERROR: fprintf(listing,"%-20s%-20s","COMMENT_ERROR",tokenString); 
			break;
		default:
			fprintf(listing,"%-20s",tokenString); 
  }
}

/* Function newStmtNode creates a new statement
 * node for syntax tree construction
 */
TreeNode * newStmtNode(StmtKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
	t->type = Integer;
    t->indentifierException=0;
    t->sibling = NULL;
    t->nodekind = StmtK;
    t->kind.stmt = kind;
    t->lineno = lineno;
  }
  return t;
}

/* Function newExpNode creates a new expression 
 * node for syntax tree construction
 */
TreeNode * newExpNode(ExpKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
	t->type = Integer;
    t->indentifierException=0;
    t->sibling = NULL;
    t->nodekind = ExpK;
    t->kind.exp = kind;
    t->lineno = lineno;

  }
  return t;
}

/* Function copyString allocates and makes a new
 * copy of an existing string
 */
char * copyString(char * s)
{ int n;
  char * t;
  if (s==NULL) return NULL;
  n = strlen(s)+1;
  t = (char*)malloc(n);
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else strcpy(t,s);
  return t;
}

/* Variable indentno is used by printTree to
 * store current number of spaces to indent
 */
static int indentno = 0;

/* macros to increase/decrease indentation */
#define INDENT indentno+=2
#define UNINDENT indentno-=2

/* printSpaces indents by printing spaces */
static void printSpaces(void)
{ int i;
  for (i=0;i<indentno;i++)
    printf(" ");
}

/* procedure printTree prints a syntax tree to the 
 * listing file using indentation to indicate subtrees
 */
void printTree( TreeNode * tree )
{
	int i;
	INDENT;
	while (tree != NULL) {
		printSpaces();
		//============================================
		//		Project 2
		//=============================================
		printf("line %d ",tree->lineno);
		if (tree->nodekind==StmtK)
		{ 
			switch (tree->kind.stmt) 
			{
				case IfK:
					fprintf(listing,"If Statement\n");
					break;
				case IfElseK:
					fprintf(listing,"If-Else Statement\n");
					break;
				case Compound:
					fprintf(listing,"Compound statement\n");
					break;
				case Decl_Var:
					fprintf(listing,"Variable Type:%s\n",expressionTypeStrings[tree->type]);//Variable Type:int
					break;
				case Decl_Func:
					fprintf(listing,"Function Id:%s Type:%s\n",tree->attr.name,expressionTypeStrings[tree->type]);
					break;
				case Params: //Parameter Type : void
					if( strcmp(tree->attr.name,"list")==0 )
						fprintf(listing,"Parameter List\n");
					else if( strcmp(tree->attr.name,"empty")==0)
						fprintf(listing,"Parameter List is empty\n");
					break;
				case Param: 
					fprintf(listing,"Parameter Type:%s\n",expressionTypeStrings[tree->type]);//Parameter Type:int
					break;
				case WhileK:
					fprintf(listing,"While Statement\n");
					break;
				case ReturnK:
					fprintf(listing,"Return\n");
					break;
				case CallK:
					fprintf(listing,"Function Call:%s\n",tree->attr.name);
					break;
				case AssignK:
					fprintf(listing,"Assign to:%s\n",tree->attr.name);
					break;
				default:
				  fprintf(listing,"Unknown ExpNode kind\n");
				  break;
		  }
	}
		else if (tree->nodekind==ExpK){
			switch (tree->kind.exp) {
				case OpK:
					fprintf(listing,"Op: "); {
						TokenType token = tree->attr.op;
						switch(token){
							case PLUS: fprintf(listing,"+\n"); break;
							case MINUS: fprintf(listing,"-\n"); break;
							case TIMES: fprintf(listing,"*\n"); break;
							case OVER: fprintf(listing,"/\n"); break;
							case LT: fprintf(listing,"<\n"); break;
							case LESSTHANEQUAL: fprintf(listing,"<=\n"); break;
							case GREATERTHAN: fprintf(listing,">\n"); break;
							case GREATERTHANEQUAL: fprintf(listing,">=\n"); break;
							case EQ: fprintf(listing,"==\n"); break;
							case NOTEQUAL: fprintf(listing,"!=\n"); break;
						}
					}
					
					break;
				case ConstK:
					if(tree->attr.val >= 0)
						fprintf(listing,"Const:%d\n",tree->attr.val);
					else if(tree->attr.val == -1)
						fprintf(listing,"Const:%d(Array as Parameter)\n",tree->attr.val);
					break;
				case IdK:
					fprintf(listing,"Id:%s\n",tree->attr.name);
					break;
				default:
				  fprintf(listing,"Unknown ExpNode kind\n");
				  break;
			}
		}
    else
		fprintf(listing,"Unknown node kind\n");
    for (i=0;i<MAXCHILDREN;i++){
         printTree(tree->child[i]);
	}
    tree = tree->sibling;
  }
  UNINDENT;
}


char* TokenString(TokenType type){
	if(type==PLUS){			return "+";	}
	else if(type==MINUS){	return "-";	}
	else if(type==TIMES){	return "*";}
	else if(type==OVER){	return "/";}
	else if(type==LT){		return "<";}
	else if(type==GREATERTHAN){		return ">";}
	else if(type==LESSTHANEQUAL){		return "<=";}
	else if(type==GREATERTHANEQUAL){		return ">=";}
	else if(type==EQ){		return "==";}
	else if(type==NOTEQUAL){		return "!=";}
	else{				return "TokenString";	}
}

