/****************************************************/
/* File: cgen.c                                     */
/* The code generator implementation                */
/* for the TINY compiler                            */
/* (generates code for the TM machine)              */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "analyze.h"
#include "code.h"
#include "cgen.h"
#include "util.h"


static symtabScope currentSymbolTable;
extern symtabScope rootSymbolTable;

static int flagDebug = 0;

static void DebugCGEN(char *s){
  if (flagDebug)
    printf("%s",s);
}
/* prototype for internal recursive code generator */
static void genCode(TreeNode * tree, int isaddr);//recursive
static void genCodeNonRecursive(TreeNode * tree, int isaddr);//non-recursive
static void GenerateExpression(TreeNode* Exp, int isaddr);
static void GenerateStmt(TreeNode* stmt);

static void GenerateLabel(char* name,int c){
  fprintf(code, "%s%d:\n", name, c);
}

static int IterateCounter(void){
  static int counter = 0;
  return counter++;
}

static int compoundException = 0;
static char currentFunctionName[250];


static void GenerateExpressionOperand(TreeNode * OpK)
{
  TreeNode *left = OpK->child[0];
  TreeNode *right = OpK->child[1];
  
  DebugCGEN("GenerateExpressionOperand\n");
  
  genCodeNonRecursive(left, FALSE); 
  PushMemoryStack("$t0"); 
  genCodeNonRecursive(right, FALSE); 
  PopMemoryStack("$t1"); 
  switch (OpK->attr.op){
    case PLUS:
      fprintf(code, "add $t0, $t0, $t1\n");
      break;
    case MINUS:
      fprintf(code, "sub $t0, $t1, $t0\n");
      break;
    case TIMES:
      fprintf(code, "mul $t0, $t1, $t0\n"); 
      break;
    case OVER:
      fprintf(code, "div $t0, $t1, $t0\n"); 
      break;
    case LT:
      fprintf(code, "slt $t0, $t1, $t0\n");
      break;
    case GREATERTHAN:
      fprintf(code, "slt $t0, $t0, $t1\n");
      break;
    case LESSTHANEQUAL:
      fprintf(code, "slt $t0, $t0, $t1\n");
      fprintf(code, "li $t1, 1\n");
      fprintf(code, "xor $t0, $t0, $t1\n");
     break;
    case GREATERTHANEQUAL:
      fprintf(code, "slt $t0, $t1, $t0\n");
      fprintf(code, "li $t1, 1\n");
      fprintf(code, "xor $t0, $t0, $t1\n"); 
     break;
    case EQ: 
      fprintf(code, "slt $t2, $t1, $t0\n");
      fprintf(code, "slt $t3, $t0, $t1\n");
      fprintf(code, "or $t4, $t2, $t3\n");
      fprintf(code, "li $t1, 1\n"); 
      fprintf(code, "xor $t0, $t4, $t1\n"); 
      break;
    case NOTEQUAL:
      fprintf(code, "slt $t2, $t0, $t1\n");
      fprintf(code, "slt $t3, $t1, $t0\n");
      fprintf(code, "or $t0, $t2, $t3\n");
      break;
  }
}
static void GenerateExpressionConstant(TreeNode * ConstK){
	int value = ConstK->attr.val;
	DebugCGEN("GenerateExpressionConstant\n");
	fprintf(code, "li $t0, %d\n", value);
}
static void GenerateExpressionIdentifier(TreeNode * IdK, int AddressMem)
{
  char * name = IdK->attr.name;
  
  DebugCGEN("GenerateExpressionIdentifier\n");
  
  symbolTable br = st_lookup2(name,currentSymbolTable);
  int relative_address = st_lookup3(name, currentSymbolTable);
  symtabScope st = search_all_symtab4(name, currentSymbolTable);

  int size = br->attr.size;

  if (st == rootSymbolTable){
    int loc = br->memoryLocation;
    if (size > 0){//array
      if (CheckIdentifierExpression(IdK)){
        TreeNode * index = IdK->child[0];
        GenerateExpression(index, FALSE);
        fprintf(code, "move $t1, $t0\n"); 
        fprintf(code, "li $t2, 4\n");
        fprintf(code, "mul $t1, $t1, $t2\n"); 
        fprintf(code, "addi $t1, $t1, %d\n",-(loc));
        fprintf(code, "la $t0, _global\n");
        fprintf(code, "add $t0, $t0, $t1\n"); 
        if (!AddressMem){
          fprintf(code, "lw $t0, 0($t0)\n");
        }
      }
      else if (CheckIdentifier(IdK)){ 
        fprintf(code, "la $t0, _global\n");
        fprintf(code, "addi $t0, $t0, %d\n", -(loc)); 
      }
    }
    else if (size == -2){
      if (CheckIdentifier(IdK)){ // id
        fprintf(code, "la $t0, _global\n");
        fprintf(code, "addi $t0, $t0, %d\n", loc);
        if (!AddressMem){
          fprintf(code, "lw $t0, 0($t0)\n");
        }
      }
      else if (CheckIdentifierExpression(IdK)){
        printf("error! not an array\n");
      }
    }
    return;
  }

  if (size > 0){
    if (CheckIdentifierExpression(IdK)){
      TreeNode * index = IdK->child[0];
      GenerateExpression(index, FALSE);
      fprintf(code, "move $t1, $t0\n"); 
      fprintf(code, "li $t2, 4\n"); 
      fprintf(code, "mul $t1, $t1, $t2\n"); 
      fprintf(code, "addi $t1, $t1, %d\n", relative_address); 
      fprintf(code, "add $t0, $fp, $t1\n"); 
      if (!AddressMem){
        fprintf(code, "lw $t0, 0($t0)\n");
      }
    }
    else if (CheckIdentifier(IdK)){ // id
      fprintf(code, "addi $t0, $fp, %d\n", relative_address); // $t0 = $fp + &id
    }
  }
  else if (size == -1){
    if (CheckIdentifierExpression(IdK)){
      TreeNode * index = IdK->child[0];
      GenerateExpression(index, FALSE);
      fprintf(code, "move $t1, $t0\n");
      fprintf(code, "li $t2, 4\n");
      fprintf(code, "mul $t1, $t1, $t2\n");
      fprintf(code, "addi $t0, $fp, %d\n", relative_address);
      fprintf(code, "lw $t0, 0($t0)\n");
      fprintf(code, "add $t0, $t0, $t1\n"); 
      if (!AddressMem){
        fprintf(code, "lw $t0, 0($t0)\n");
      }
    }
    else if (CheckIdentifier(IdK)){
      fprintf(code, "addi $t0, $fp, %d\n", relative_address); 
      fprintf(code, "lw $t0, 0($t0)\n"); 
    }
  }
  else if (size == -2){
    if (CheckIdentifier(IdK)){ // id
      fprintf(code, "addi $t0, $fp, %d\n", relative_address); 
      if (!AddressMem){
        fprintf(code, "lw $t0, 0($t0)\n"); 
      }
    }
    else if (CheckIdentifierExpression(IdK)){
        printf("error! not an array\n");
    }
  }
}
void GenerateExpression(TreeNode * tree, int AddressMem){
  switch (tree->kind.exp) {
    case ConstK:
      GenerateExpressionConstant(tree);
      break;
    case IdK:
      GenerateExpressionIdentifier(tree, AddressMem);
      break;
    case OpK:
      GenerateExpressionOperand(tree);
      break;
    default:
      break;
    }
}

static void GenerateStmtDeclarationFunction(TreeNode * Decl_Func)
{
  TreeNode * Compound = Decl_Func->child[2];
  
  DebugCGEN("GenerateStmtDeclarationFunction\n");
  
  symtabScope next_symtab = currentSymbolTable->child;
  char * func_name = Decl_Func->attr.name;
  if (strcmp(func_name, "main") == 0){
    fprintf(code, "%s:\n", "_main");
    strcpy(currentFunctionName, "_main");

  }
  else{
    fprintf(code, "%s:\n", func_name);
    strcpy(currentFunctionName, func_name);
 
  }

  while (next_symtab->visited == 1){
    next_symtab = next_symtab->sibling;
  }
  next_symtab->visited = 1;
  currentSymbolTable = next_symtab;
  PushMemoryStack("$fp");
  fprintf(code, "move $fp, $sp\n");
  PushMemoryStack("$ra");
  fprintf(code, "addi $sp, $sp, %d\n", next_symtab->localMemory + 4);
  compoundException = TRUE;
  genCodeNonRecursive(Compound, FALSE);
  fprintf(code, "addi $sp, $sp, %d\n", -(next_symtab->localMemory + 4));
  PopMemoryStack("$ra");
  PopMemoryStack("$fp");
  fprintf(code, "jr $ra\n");

  currentSymbolTable = currentSymbolTable->parent;
}

static void GenerateStmtCompound(TreeNode * Compound)
{
  int exception = compoundException;
  TreeNode * statementList = Compound->child[1];
  symtabScope next_symtab = currentSymbolTable->child;

  
  DebugCGEN("GenerateStmtCompound\n");
  
  if (exception == FALSE){
    while (next_symtab->visited == 1){
      next_symtab = next_symtab->sibling;
    }
    next_symtab->visited = 1;
    currentSymbolTable = next_symtab;
    PushMemoryStack("$fp");
    fprintf(code, "move $fp, $sp\n"); 
    PushMemoryStack("$ra");
    fprintf(code, "addi $sp, $sp, %d\n", next_symtab->localMemory + 4); 
  }
  else{
    compoundException = FALSE;
  }

  genCode(statementList, FALSE);

  if (exception == FALSE){
    fprintf(code, "addi $sp, $sp, %d\n", -(next_symtab->localMemory + 4)); 
    PopMemoryStack("$ra");
    PopMemoryStack("$fp");
    currentSymbolTable = currentSymbolTable->parent;
  }
}

static void GenerateStmtIfK(TreeNode *IfK)
{
  int exitIf = IterateCounter();
  TreeNode * expression = IfK->child[0];
  TreeNode * statement = IfK->child[1];

  DebugCGEN("GenerateStmtIfK\n");
  
  genCodeNonRecursive(expression, FALSE);
  fprintf(code, "beq $t0, $zero, If_End%d\n",exitIf);
  genCodeNonRecursive(statement, FALSE);
  GenerateLabel("If_End", exitIf);
}

static void GenerateStmtIfElseK(TreeNode * IfElseK)
{
  int ifElse = IterateCounter();
  int ifEnd = IterateCounter();
  
  TreeNode * expression = IfElseK->child[0];
  TreeNode * statement = IfElseK->child[1];
  TreeNode * elseStatement = IfElseK->child[2];

  DebugCGEN("GenerateStmtIfElseK\n");

  genCodeNonRecursive(expression,FALSE);
  fprintf(code, "beq $t0, $zero, If_Else%d\n",ifElse);
  genCodeNonRecursive(statement, FALSE);
  fprintf(code, "j %d\n",ifEnd);
  GenerateLabel("If_Else", ifElse);
  genCodeNonRecursive(elseStatement, FALSE);
  GenerateLabel("If_End", ifEnd);
}

static void GenerateStmtWhileK(TreeNode *WhileK)
{
  int whileStart = IterateCounter();
  int whileEnd = IterateCounter();
  TreeNode *condition_exp = WhileK->child[0];
  TreeNode *statement = WhileK->child[1];
  
  DebugCGEN("GenerateStmtWhileK\n");
  
  GenerateLabel("While_Start", whileStart);
  genCodeNonRecursive(condition_exp, FALSE);
  fprintf(code, "beq $t0, $zero, While_End%d\n",whileEnd);
  genCodeNonRecursive(statement, FALSE);
  fprintf(code, "j While_Start%d\n", whileStart);
  GenerateLabel("While_End", whileEnd);
}

static void GenerateStmtReturn(TreeNode *ReturnK){

  TreeNode * expression = ReturnK->child[0];
  symtabScope st=currentSymbolTable;
  DebugCGEN("GenerateStmtReturn\n");
  
  if (expression){
    genCodeNonRecursive(expression,FALSE);
    fprintf(code, "move $v0, $t0\n");
  }
  while (st->nestedLevel > 0){
    fprintf(code, "addi $sp, $sp, %d\n", -(st->localMemory + 4)); 
    PopMemoryStack("$ra");
    PopMemoryStack("$fp");
    st = st->parent;
  }
  fprintf(code, "jr $ra\n");
}
static int CountNumArguments(TreeNode * Args){
	
  int count = 0;
  DebugCGEN("CountNumArguments\n");
  
  while (Args){
    count++;
    Args=Args->sibling;
  }
  DebugCGEN("CountNumArguments End\n");
  return count;
}
static TreeNode* GetArguments(TreeNode * Args, int i){
  int count = 1;
  while (Args){
    if (i == count){
      return Args;
      break;
    }
    count++;
    Args->sibling;
  }
  return NULL;
}


static void GenerateStmtCall(TreeNode * CallK)
{
  int i;
  char * func_name = CallK->attr.name;

  TreeNode * args = CallK->child[1];

  DebugCGEN("GenerateStmtCall\n");
  int arg_count = CountNumArguments(args);
  

  for (i = arg_count; i >= 1; i--){
    TreeNode * arg = GetArguments(args, i);
    genCodeNonRecursive(arg,FALSE);
    PushMemoryStack("$t0");
  }

  if (strcmp(func_name,"input") == 0){
    fprintf(code, "li $v0, 5\n"); 
    fprintf(code, "syscall\n");
  }
  else if (strcmp(func_name, "output") == 0){
    //fprintf(code, "la $a0, out_string\n");
    //fprintf(code, "li $v0, 4\n"); 
   // fprintf(code, "syscall\n");
    fprintf(code, "la $a0, space\n");
    fprintf(code, "li $v0, 4\n"); 
    fprintf(code, "syscall\n");
    fprintf(code, "lw $a0, 0($sp)\n"); 
    fprintf(code, "li $v0, 1\n");
    fprintf(code, "syscall\n");
  }
  else{
    fprintf(code, "jal %s\n", func_name);
  }
  fprintf(code, "move $t0, $v0\n");
  PopNumberMemoryStack(arg_count);

  DebugCGEN("GenerateStmtCall End\n");
}
static void GenerateStmtAssignment(TreeNode * AssignK)
{

  TreeNode *left = AssignK->child[0];
  TreeNode *right = AssignK->child[1];
  
  DebugCGEN("GenerateStmtAssignment\n");
  
  genCodeNonRecursive(left, TRUE);
  PushMemoryStack("$t0");
  genCodeNonRecursive(right, FALSE);
  PopMemoryStack("$t1"); 
  fprintf(code, "sw $t0, 0($t1)\n"); 
}
static void GenerateStmt(TreeNode * tree)
{
  switch (tree->kind.stmt){
    case Decl_Var:
      break;
    case Decl_Func:
      GenerateStmtDeclarationFunction(tree);
      break;
    case Params:
      break;
    case Param:
      break;
    case Compound:
      GenerateStmtCompound(tree);
      break;
    case IfK:
      GenerateStmtIfK(tree);
      break;
    case IfElseK:
      GenerateStmtIfElseK(tree);
      break;
    case WhileK:
      GenerateStmtWhileK(tree);
      break;
    case ReturnK:
      GenerateStmtReturn(tree);
      break;
    case CallK:
      GenerateStmtCall(tree);
      break;
    case AssignK:
      GenerateStmtAssignment(tree);
      break;
    default:
      break;
  }
}


/*
non-recursive code generation function
*/
static void genCodeNonRecursive(TreeNode * tree,int isaddr){
  if (tree != NULL){
    switch (tree->nodekind) {
      case StmtK:
        GenerateStmt(tree);
        break;
      case ExpK:
        GenerateExpression(tree, isaddr);
      default:
        break;
    }
  }
}
/*
recursive code generation 
*/
static void genCode(TreeNode * tree, int isaddr){//recursive
  if (tree != NULL)
  {
    switch (tree->nodekind) 
	{
      case StmtK:
        GenerateStmt(tree);
        break;
      case ExpK:
        GenerateExpression(tree, isaddr);
      default:
        break;
    }
    genCode(tree->sibling, isaddr);
  }
}
/*
function inits all symtabScope's visited flag
*/
static void InitializeSymbleTables(symtabScope parent){
  if (parent == NULL)    return;
  parent->visited = 0;
  InitializeSymbleTables(parent->child);
  InitializeSymbleTables(parent->sibling);
}
void codeGen(TreeNode * declarationList, char * codefile)
{
  TreeNode * declaration = declarationList;
  char * s = malloc(strlen(codefile) + 7);
  InitializeSymbleTables(rootSymbolTable);
  currentSymbolTable = rootSymbolTable;
  strcpy(s, "File : ");  strcat(s, codefile);
  emitComment("C- Compilation to MIPS Code");
  emitComment(s);

  fprintf(code, ".data\n");
  fprintf(code, ".align 2\n");
  fprintf(code, "space: .ascii \"\\t\\t\\t\\n\"\n");
  fprintf(code, ".data\n");
  fprintf(code, "out_string: .asciiz	\"Output: \"\n");	
  fprintf(code, "_global: .space %d\n", -(rootSymbolTable->localMemory+4));	
  fprintf(code, ".text\n");

  while (declaration)
  {
    genCodeNonRecursive(declaration,FALSE);
    declaration = declaration->sibling;
  }
  fprintf(code, "main:\n");
  fprintf(code, "move $fp, $sp\n");
  fprintf(code, "jal _main\n");
  fprintf(code, "li $v0, 10\n");
  fprintf(code, "syscall\n");
  
}
