/****************************************************/
/* File: analyze.c                                  */
/* Semantic analyzer implementation                 */
/* for the TINY compiler                            */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "analyze.h"
#include "util.h"
/* Procedure traverse is a generic recursive 
 * syntax tree traversal routine:
 * it applies preProc in preorder and postProc 
 * in postorder to tree pointed to by t
 */



extern char* TokenString(TokenType type);

//Symbol Table Global Declarations
static char* expressionTypeStrings[]={"Void","Integer","Array"};
static int indentifierException=0;
symtabScope rootSymbolTable=NULL;
static symtabScope currentSymbolTable=NULL;
static paramlist parameterStart=NULL;//start of current func param list
static int NewScopeException=0;


static void traverse( TreeNode * t,
               void (* preProc) (TreeNode *),
               void (* postProc) (TreeNode *) )
{ if (t != NULL)
  { preProc(t);
    { int i;
      for (i=0; i < MAXCHILDREN; i++){
        traverse(t->child[i],preProc,postProc);
        if(t->nodekind==StmtK && t->kind.stmt==Compound && i==0)//localDeclarations
          indentifierException=0;
      }
    }
    postProc(t);
    traverse(t->sibling,preProc,postProc);
  }
}

/* the hash function */
static int hash ( char * key )
{ int temp = 0;
  int i = 0;
  while (key[i] != '\0')
  { temp = ((temp << SHIFT) + key[i]) % SIZE;
    ++i;
  }
  return temp;
}

static symtabScope SymbolTable(void){
  symtabScope t;
  InitStruct(t,symtabScope,struct scopeStruct);
  return t;
}
static void CreateNewSymtabScope(void)
{
  symtabScope new_t,first_child;
  InitStruct(new_t,symtabScope,struct scopeStruct);
  int rank=0;
  new_t->localMemory = -8;
  new_t->parameterMemory = 4;
  new_t->parent = currentSymbolTable;

  first_child=NULL;
  new_t->nestedLevel = currentSymbolTable->nestedLevel+1;
  first_child = currentSymbolTable->child;
  if(first_child==NULL){
    new_t->rank=rank;
    currentSymbolTable->child = new_t;
  }else{
    rank++;
    symtabScope child=first_child;
    while(child->sibling!=NULL){
      child = child->sibling;
      rank++;
    }
    child->sibling=new_t;
    new_t->rank=rank;
  }
  //set new_t as new currentSymbolTable
  currentSymbolTable = new_t;
}
static void InitializeSymbolTable(void)
{
  currentSymbolTable = SymbolTable();
  currentSymbolTable->localMemory = -4;
  currentSymbolTable->parameterMemory = 4;
  rootSymbolTable = currentSymbolTable;
}
static symbolTable Base_record(TreeNode *node,char* symbolType){
  symbolTable r; listOfLine l;
  InitStruct(r,symbolTable,struct symbolTableStruct);
  InitStruct(l,listOfLine,struct listOfLineStruct);
  //set record attributes
  l->num = node->lineno;
  r->name = node->child[0]->attr.name;
  r->type = node->type;
  r->symbolType=copyString(symbolType);                                       //value of attr.size
  if( strcmp(symbolType,"parameter")==0 || strcmp(symbolType,"variable")==0 ){//parameter int[]  = -1
    if(node->child[1]) r->attr.size=node->child[1]->attr.val;                   //parameter int    = -2
    else r->attr.size=-2;                                                       //int[Const]       = Const
  }else if( strcmp(symbolType,"function")==0 ){                                //int              = -2
    //resolved at Post procedure
  }
  return r;
}

static symbolTable SearchSymbolTable(symtabScope the_symtab,char* name){
  int hv = hash(name);
  symbolTable r=the_symtab->table[hv];
  while( r!=NULL && strcmp(name,r->name)!=0 ){
    r = r->next;
  }
  return r;
}
symbolTable st_lookup(char* name){//search from currentSymbolTable to rootSymbolTable
  symtabScope the_symtab = currentSymbolTable;
  symbolTable t = NULL;
  while (the_symtab != NULL){
    t = SearchSymbolTable(the_symtab, name);
    if (t) return t;
    the_symtab = the_symtab->parent;
  }
  return t;
}
symbolTable st_lookup2(char* name, symtabScope the_symtab){//search from the_symtab to rootSymbolTable
  symbolTable t = NULL;
  while (the_symtab != NULL){
    t = SearchSymbolTable(the_symtab, name);
    if (t) return t;
    the_symtab = the_symtab->parent;
  }
  return t;
}
int st_lookup3(char* name, symtabScope the_symtab){//search Id and return relative address
  symbolTable t = NULL;
  int rel_add = 0;
  while (the_symtab != NULL){
    t = SearchSymbolTable(the_symtab, name);
    if (t){
      rel_add += t->memoryLocation;
      return rel_add;
    };
    rel_add += the_symtab->parameterMemory;
    the_symtab = the_symtab->parent;
    rel_add += -(the_symtab->localMemory + 0);
  }
  return 0;
}
symtabScope search_all_symtab4(char* name, symtabScope the_symtab){//return found symtabScope
  symbolTable t = NULL;
  while (the_symtab != NULL){
    t = SearchSymbolTable(the_symtab, name);
    if (t){
      return the_symtab;
    };
    the_symtab = the_symtab->parent;
  }
  return 0;
}
static void PushScopeStack(TreeNode * node){//add only line number  //use variable IdK | CallK
  //check duplication in symtab_current
  char * name = node->attr.name;
  symbolTable search=st_lookup(name);
  if( search == NULL ){
    Error=TRUE;
    printf("Line %d : %s is not declared\n",node->lineno,name);
  }else{    
    listOfLine t;
    int line=node->lineno;
    InitStruct(t,listOfLine,struct listOfLineStruct);
    t->num=line;
    listOfLine lines=search->lines;

    if(lines==NULL)
      search->lines=t;
    else{
      while(lines->next!=NULL){
        lines=lines->next;
      }
      if(lines->num==line) return;
      lines->next=t;
    }
  }
}

static symbolTable PushRecordStack(TreeNode * node,char* symbolType){//Decl_Func | Decl_Var //declare variable

  //check duplication in symtab_current
  char * name = node->child[0]->attr.name;
  int line = node->child[0]->lineno;
  symbolTable search=SearchSymbolTable(currentSymbolTable, name);
  symbolTable r=NULL;
  if( search != NULL ){
    Error=TRUE;
    printf("Line %d : %s is already declared in this scope\n",node->lineno,name);
    return NULL;
  }else if( search == NULL ){
    r = Base_record(node,symbolType);
    int memoryLocation=0;
    if (strcmp(symbolType, "variable") == 0){
      int size=r->attr.size;
      if (size == -2){// int
        memoryLocation = currentSymbolTable->localMemory;
        currentSymbolTable->localMemory += -4;
      }
      else{//int[]
        size *= 4;
        currentSymbolTable->localMemory -= size;
        memoryLocation = currentSymbolTable->localMemory + 4;
      }
    }
    else if(strcmp(symbolType,"function")==0){//function are refered by Label :)
      memoryLocation = -1;//currentSymbolTable->localMemory;
      //currentSymbolTable->localMemory+=-4;
    }else if(strcmp(symbolType,"parameter")==0){
      memoryLocation = currentSymbolTable->parameterMemory;
      currentSymbolTable->parameterMemory+=4;
	}

    listOfLine t;
    InitStruct(t,listOfLine,struct listOfLineStruct);
    t->num=line;
    r->lines=t;
    r->memoryLocation = memoryLocation;
    int hv = hash(name);
    symbolTable records = currentSymbolTable->table[hv];

    if(records){
      while(records->next!=NULL) records=records->next;
      records->next=r;
    }
    else
      currentSymbolTable->table[hv]=r;
    currentSymbolTable->count++;

  }
  return r;
}


static void AddParameter(symbolTable r){
  paramlist new_param;
  InitStruct(new_param,paramlist,struct parameterList);
  new_param->record = r;
  new_param->next = NULL;
 
  if(!parameterStart){
    parameterStart=new_param;    
  }
  else{
    paramlist params=parameterStart;    
    while(params->next!=NULL) params=params->next;
    params->next=new_param;
  }
}



/*
  Symbol Table(st) build Functions
*/
static void BuildDeclVarSymtab(TreeNode* Decl_Var){
  PushRecordStack(Decl_Var,"variable");
  TreeNode* IdK = Decl_Var->child[0];
  IdK->indentifierException=1;
}

static void BuildDeclFuncSymtabPre(TreeNode* Decl_Func){
  TreeNode* IdK = Decl_Func->child[0];
  IdK->indentifierException=1;
 /* base_record Decl_Func_record = */PushRecordStack(Decl_Func,"function");
  NewScopeException=1;
}
static void BuildDeclFuncSymtabPost(TreeNode* Decl_Func){//resolve parameter types
  //base_record Decl_Func_record = PushRecordStack(Decl_Func,"function");
  symbolTable Decl_Func_record = SearchSymbolTable(currentSymbolTable,Decl_Func->child[0]->attr.name);
  Decl_Func_record->attr.params = parameterStart;


  paramlist params=parameterStart;
  symbolTable param;
  // printf("%s parameter type : ",Decl_Func_record->name);
  while(params){
    param=params->record;
    if(!param){
      // printf("param is NULL!!!\n");
      return;
    }
    // printf("%d ",param->attr.size);
    params=params->next;
  }
  // puts("");
}
static void BuildParametersSymtabPre(TreeNode* t){
  t = t;
  CreateNewSymtabScope();
  parameterStart=NULL;
}
static void BuildParameterSymtabPre(TreeNode* Param){
  symbolTable r = SearchSymbolTable(currentSymbolTable, Param->child[0]->attr.name);
  if(r==NULL){
    r = PushRecordStack(Param,"parameter");
    AddParameter(r);
  }else{
    Error=TRUE;
    printf("Line %d : %s is already declared in this scope\n",Param->lineno,Param->child[0]->attr.name);
  }
  TreeNode* IdK = Param->child[0];
  IdK->indentifierException=1;
}
static void BuildCompoundSymtabPre(TreeNode* t){
  t = t;
  if(NewScopeException==1){
    NewScopeException=0;
    return;
  }
  indentifierException=1;
  CreateNewSymtabScope();
}
static void BuildCompoundSymtabPost(TreeNode * t){
  t = t;
  currentSymbolTable = currentSymbolTable->parent;
}
static void BuildIdentifierSymtabPre(TreeNode *t){
  if(t->indentifierException){
    return;
    ;
  }
  //if(!indentifierException || currentSymbolTable==rootSymbolTable)
    PushScopeStack(t);
}

static void SymbolTablePreOrder( TreeNode * t){
  if (t->nodekind==StmtK){
    switch (t->kind.stmt){
      case Decl_Var: BuildDeclVarSymtab(t); break;
      case Decl_Func:BuildDeclFuncSymtabPre(t);break;
      case Params:  BuildParametersSymtabPre(t); break;
      case Param:   BuildParameterSymtabPre(t);  break;
      case Compound:BuildCompoundSymtabPre(t); break;
      case IfK:     break;
      case IfElseK:   break;
      case WhileK:    break;
      case ReturnK:   break;
      case CallK:     break;
      case AssignK:   break;
    }
  }else if (t->nodekind==ExpK){
    //printf("#SymbolTablePreOrder ExpK %s\n",ExpKind_str(t->nodekind));
    switch (t->kind.exp) {
      case OpK:     break;
      case ConstK:    break;
      case IdK:     BuildIdentifierSymtabPre(t); break;
      }
    }
}

static void SymbolTablePostOrder( TreeNode * t){
  if (t->nodekind==StmtK){
    switch (t->kind.stmt){
      case Decl_Var:    break;
      case Decl_Func: BuildDeclFuncSymtabPost(t);break;
      case Params:    break;
      case Param:   break;
      case Compound: BuildCompoundSymtabPost(t); break;
      case IfK:     break;
      case IfElseK:   break;
      case WhileK:    break;
      case ReturnK:   break;
      case CallK:     break;
      case AssignK:   break;
    }
  }else if (t->nodekind==ExpK){
    switch (t->kind.exp) {
      case OpK:     break;
      case ConstK:    break;
      case IdK:     break;
      }
    }
}

/*
  SymTab Print Function
*/
static void PrintSpaceChar(int count)
{ int i;
  for (i=0;i<count;i++)
    printf("  ");
}
static void PrintSymtab(symtabScope st){
  symbolTable record;
  listOfLine  line; 
  char str[255]; int str_len=0;
  int i;
  PrintSpaceChar(st->nestedLevel); printf("Scope nestedLevel : %d parameterMemory : %d localMemory : %d\n ",st->nestedLevel,st->parameterMemory,st->localMemory);
  PrintSpaceChar(st->nestedLevel); printf("Variable Name Location  Type    Symbol_Type Array(size) Line Numbers\n");
  PrintSpaceChar(st->nestedLevel); printf("------------- -------- -------- ----------- ----------- ------------\n");

  for(i=0;i<SIZE;i++){
    if( (record=st->table[i]) != NULL){
      PrintSpaceChar(st->nestedLevel); 
      while(record!=NULL){
        line = record->lines;
		printf("%-14s " , record->name);
        printf("%-8d ",record->memoryLocation);
        printf("%-8s ",expressionTypeStrings[record->type]);
        printf("%-11s ",record->symbolType);

        if( !strcmp(record->symbolType,"parameter") || !strcmp(record->symbolType,"variable")){
          if(record->attr.size>=0)
            sprintf(str,"yes(%d)",record->attr.size);
          else if(record->attr.size==-1)
            sprintf(str,"yes");
          else
            sprintf(str,"");
        }else{
          sprintf(str,"");
        } printf("%-11s ",str);

        str_len=0; sprintf(str,"");
        while(line != NULL){
          //sprintf(str+str_len,"%d ",line->num);
          if(line->num){
            printf("%d ",line->num);
            str_len=strlen(str);
          }
          line=line->next;
        } puts("");//printf("%-11s\n",str);

        record=record->next;
      }
    }
  } puts("");
}
static void PrintSymtabAll(symtabScope p){//parent
  symtabScope c = NULL;//child
  symtabScope s = NULL;//sibling
  if(p){
    //if(p->count) 
      PrintSymtab(p);
    if((c=p->child)!=NULL){
      PrintSymtabAll(c);
    }
    if((s=p->sibling)!=NULL){
      PrintSymtabAll(s);
    }
  }
}
static void AddInputOuput(void){//input output function
  //input function
  symbolTable r; listOfLine l; paramlist param;
  InitStruct(r,symbolTable,struct symbolTableStruct);
  InitStruct(l,listOfLine,struct listOfLineStruct);
  l->num = 0;
  r->lines=l;
  r->name = "input";
  r->type = Integer;
  r->symbolType=copyString("function");
  r->attr.params = NULL;
  r->memoryLocation = -1;//rootSymbolTable->localMemory;
  //rootSymbolTable->localMemory+=-4;  
  rootSymbolTable->table[hash("input")]=r;



  //output function
  InitStruct(r,symbolTable,struct symbolTableStruct);
  InitStruct(l,listOfLine,struct listOfLineStruct);
  InitStruct(param,paramlist,struct parameterList);
  l->num = 0;
  r->name = "output";
  r->type = Void;
  r->symbolType=copyString("function");
  r->lines = l;
  r->memoryLocation = -1;// rootSymbolTable->localMemory;
  //rootSymbolTable->localMemory+=-4;
  {
    symbolTable param_record;
    InitStruct(param_record,symbolTable,struct symbolTableStruct);
    param_record->type=Integer;
    param_record->attr.size = -2;
    param->record = param_record;
  }  
  r->attr.params = param;
  rootSymbolTable->table[hash("output")]=r;
  rootSymbolTable->count+=2;  
}

/* Function buildSymtab constructs the symbol 
 * table by preorder traversal of the syntax tree
 */
void buildSymtab(TreeNode * syntaxTree){
  InitializeSymbolTable();
  AddInputOuput();
  traverse(syntaxTree,SymbolTablePreOrder,SymbolTablePostOrder);
  if (TraceAnalyze){
    printf("\nSymbol table:\n\n");
    PrintSymtabAll(rootSymbolTable);
  }
}

//========================================================
//		TYPE CHECKING
//========================================================
static symbolTable CurrentDeclFuncActivationRecord=NULL;
static int DeclarationFunctionReturn=0;

static int IsVariableArray(char* name){
  symbolTable var_record=st_lookup(name);
  if(var_record 
    && ( strcmp(var_record->symbolType,"variable")||strcmp(var_record->symbolType,"parameter") ) 
    && var_record->attr.size != -2)
    return 1;
  return 0;
}
static int IsVariableInteger(char* name){
  symbolTable var_record=st_lookup(name);
  if(var_record 
    && ( strcmp(var_record->symbolType,"variable")||strcmp(var_record->symbolType,"parameter") ) 
    && var_record->attr.size == -2)
    return 1;
  return 0; 
}

int CheckIdentifier(TreeNode * node){
  if(node->nodekind==ExpK && node->kind.exp==IdK && node->child[0]==NULL)
    return 1;
  return 0;
}
int CheckIdentifierExpression(TreeNode * node){
  if(node->nodekind == ExpK && node->kind.exp==IdK && node->child[0]!=NULL)
    return 1;
  return 0;
}

static void TypeCheckDeclarationVarPostOrder(TreeNode *Decl_Var){
  char * name = Decl_Var->child[0]->attr.name;
  symbolTable record = st_lookup(name);// SearchSymbolTable(currentSymbolTable,name);
  //PrintSymtab(currentSymbolTable);
  if(record){
    // printf("TypeCheckDeclarationVarPostOrder(%s) %s -lev %d\n",name,expressionTypeStrings[record->type],currentSymbolTable->nestedLevel);
    if(record->type == Void){
      Error=1;
      printf("Line %d : %s - variable should not be declared as Void\n",Decl_Var->lineno,name);
    }
  }else{
    printf("Line %d : ##Fatal Error##-can not find symbolTable for Decl_Var %s\n",Decl_Var->lineno,name);
  }
}

static void TypeCheckDeclarationFuncPreOrder(TreeNode *Decl_Func){
  char* name = Decl_Func->child[0]->attr.name;
  symtabScope child=currentSymbolTable->child;
  CurrentDeclFuncActivationRecord = st_lookup(name);
  DeclarationFunctionReturn=0;
  NewScopeException=1;  
  while(child!=NULL){
    if(child->visited){
      child = child->sibling;
    }
    else{//this is our next symtabScope
      child->visited=1;
      currentSymbolTable=child;      
      break;
    }
  }
}
static void TypeCheckDeclarationFuncPostOrder(TreeNode * Decl_Func){
  Decl_Func = Decl_Func;
  if(!DeclarationFunctionReturn && CurrentDeclFuncActivationRecord->type!=Void){
    int line = CurrentDeclFuncActivationRecord->lines->num;
    char* name = CurrentDeclFuncActivationRecord->name;
    printf("Line %d : function %s should return value\n",line,name);
  }
  CurrentDeclFuncActivationRecord = NULL;
}
//void tc_Params_Post(){}
static void TypeCheckParameterPostOrder(TreeNode * Param){
  char * name = Param->child[0]->attr.name;
  int line = Param->child[0]->lineno;
  symbolTable record = SearchSymbolTable(currentSymbolTable,name);
  if(record){
    // printf("TypeCheckParameterPostOrder(%s) %s -lev %d\n",name,expressionTypeStrings[record->type],currentSymbolTable->nestedLevel);
    if(record->type == Void){
      Error=1;
      printf("Line %d : %s - parameter should not be declared as Void\n",line,name);
    }
  }else{
    printf("##Fatal Error##-can not find symbolTable for Param %s\n",name);
  }
}
void TypeCheckCompoundrPreOrder(TreeNode *Compound){
  Compound = Compound;
  symtabScope child=currentSymbolTable->child;

  if(NewScopeException){
    NewScopeException=0;
    return;
  }
  else{
    while(child!=NULL){
      if(child->visited){
        child = child->sibling;        
      }
      else{
        child->visited=1;
        currentSymbolTable=child;
        return;
      }
    }
  }
}
void TypeCheckCompoundrPostOrder(TreeNode *Compound){
  Compound = Compound;
  currentSymbolTable=currentSymbolTable->parent;
}
static void TypeCheckIfKPostOrder(TreeNode * IfK){
  TreeNode * exp = IfK->child[0];
  if(exp->type != Integer){
    printf("Line %d : If statement's condition expression should be Integer\n",IfK->lineno);
  }
}
static void TypeCheckIfElsePostOrder(TreeNode * IfElseK){
  TypeCheckIfKPostOrder(IfElseK);
}
static void TypeCheckWhilePostOrder(TreeNode * WhileK){
  TreeNode * exp = WhileK->child[0];
  if(exp->type != Integer){
    printf("Line %d : While statement's condition expression should be Integer\n",WhileK->lineno);    
  }
}
static void TypeCheckReturnPostOrder(TreeNode * ReturnK){
  if(CurrentDeclFuncActivationRecord==NULL){
    printf("Line %d : return statement should be in function\n",ReturnK->lineno);
  }else{  
    TreeNode *exp = ReturnK->child[0];
    if(exp==NULL && CurrentDeclFuncActivationRecord->type==Void){
      ;
    }else if(exp==NULL && CurrentDeclFuncActivationRecord->type!=Void){
      printf("Line %d : return statement - function %s should return Integer\n",ReturnK->lineno,CurrentDeclFuncActivationRecord->name);
    }else if(exp!=NULL && CurrentDeclFuncActivationRecord->type==Void){
      printf("Line %d : return statement - function %s\'s return type should be Void\n",exp->lineno,CurrentDeclFuncActivationRecord->name);
    }else if(exp!=NULL && CurrentDeclFuncActivationRecord->type!=exp->type){
      printf("Line %d : return statement - function %s\'s return type should be %s\n",exp->lineno,CurrentDeclFuncActivationRecord->name,expressionTypeStrings[CurrentDeclFuncActivationRecord->type]);
    }
  }
  DeclarationFunctionReturn=1;
}

static void TypeCheckCallPostOrder(TreeNode* CallK){//match function arguments
  char* func_name=CallK->attr.name;
  TreeNode* args=CallK->child[1];//call(args)
  symbolTable func_record=st_lookup(func_name);
  if(!func_record) {
    return;
  }
  paramlist params=func_record->attr.params;//definition of called function


  if( strcmp(func_record->symbolType,"function")!=0 ){
    printf("Line %d : %s is not a function\n",CallK->lineno,func_name);
  }else{    
    int count=1;//counter for parameter like #1 #2 #3
    while(params!=NULL && args!=NULL){
      int error=0;
      char message[255];
      symbolTable param_record=params->record;
      // printf("#%d Definition %d  Call %s\n",count,param_record->attr.size,ExpType_str(args->type));

      if(param_record->attr.size==-2){//int parameter
        if(args->type != Integer){
          error=1;
          sprintf(message,"function %s\'s #%d should be Integer",func_name,count);
        }
      }else if(param_record->attr.size==-1){//arr parameter
        if(args->type != Array){
          error=1;
          sprintf(message,"function %s\'s #%d should be Array",func_name,count);
        }
      }else{
        error=1;
        sprintf(message,"this should be never happen");
      }
      if(error){
        printf("Line %d : %s\n",args->lineno,message);
      }
      args=args->sibling;
      params=params->next;
      count++;
    }
    if(params==NULL && args!=NULL){//err
      printf("Line %d : %s - there is no #%d in function definition\n",args->lineno,func_name,count);
    }else if(params!=NULL && args==NULL){//err
      printf("Line %d : %s - there should be more argument to call function",CallK->lineno,func_name);
    }

    CallK->type = func_record->type;
  }
} 
static void TypeCheckAssignPostOrder(TreeNode *AssignK){
  TreeNode *var,*exp;
  var = AssignK->child[0];
  exp = AssignK->child[1];
  if(var->type != exp->type){
    printf("Line %d : Assign type miss match - try to assign to %s from %s\n",AssignK->lineno,expressionTypeStrings[var->type],expressionTypeStrings[exp->type]);
  }
}
static void TypeCheckOperandPostOrder(TreeNode * OpK){
  TreeNode *exp1,*exp2;
  exp1 = OpK->child[0]; 
  exp2 = OpK->child[1];
  if(exp1->type!=Integer){
    printf("Line %d : %s - Binary Op\'s left_hand_side should be Integer\n",exp1->lineno,TokenString(OpK->attr.op));
  }
  if(exp2->type!=Integer){
    printf("Line %d : %s - Binary Op\'s right_hand_side should be Integer\n",exp2->lineno,TokenString(OpK->attr.op));
  }
}
//void tc_ConstK_Post(){}
//void tc_IdK_Pre(TreeNode * node){}
static void TypeCheckIdentifierPostOrder(TreeNode * IdK){
  if(!st_lookup(IdK->attr.name)){
    Error=TRUE;
    printf("Line %d : %s is used without declaraition\n",IdK->lineno,IdK->attr.name);
  }
  else if(IsVariableArray(IdK->attr.name)){//arr type
    if(CheckIdentifier(IdK)){
      IdK->type = Array;
    }else if(CheckIdentifierExpression(IdK)){
      TreeNode * exp = IdK->child[0];
      if(exp->type != Integer){
        printf("Line %d : array %s\'s index should be Integer\n",exp->lineno,IdK->attr.name);
        return;
      }
      IdK->type = Integer;
    }
  }else if(IsVariableInteger(IdK->attr.name)){//int type
    if(CheckIdentifierExpression(IdK)){
      TreeNode *exp = IdK->child[0];
      printf("Line %d : tried to index int type variable %s\n",exp->lineno,IdK->attr.name);
      return;
    }
    IdK->type = Integer;
  }
}


/* Procedure checkNode performs
 * type checking at a single tree node
 */
static void PreOrderCheckNode(TreeNode *t){
  if (t->nodekind==StmtK){ 
    switch (t->kind.stmt){
      case Decl_Func:
        TypeCheckDeclarationFuncPreOrder(t);
        break;
      case Compound:
        TypeCheckCompoundrPreOrder(t);
        break;
    }
  }
}
static void PostOrderCheckNode(TreeNode *t){ 
  if (t->nodekind==StmtK){
    // printf("PostOrderCheckNode - %s\n",StmtKind_str(t->kind.stmt));
    switch (t->kind.stmt){
      case Decl_Var:  TypeCheckDeclarationVarPostOrder(t); break;
      case Decl_Func: TypeCheckDeclarationFuncPostOrder(t); break;
      case Params:  break;
      case Param:     TypeCheckParameterPostOrder(t); 
      break;
      case Compound:  TypeCheckCompoundrPostOrder(t);   break;
      case IfK:       TypeCheckIfKPostOrder(t);       break;
      case IfElseK:   TypeCheckIfElsePostOrder(t);   break;
      case WhileK:    TypeCheckWhilePostOrder(t);    break;
      case ReturnK:   TypeCheckReturnPostOrder(t);   break;
      case CallK:     TypeCheckCallPostOrder(t);     break;
      case AssignK:   TypeCheckAssignPostOrder(t);   break;
      default:
        fprintf(listing,"Unknown StmNode kind\n");
        break;
    }
  }else if (t->nodekind==ExpK){
    // printf("PostOrderCheckNode - %s\n",ExpKind_str(t->kind.stmt));
    switch (t->kind.exp) {
      case OpK:   TypeCheckOperandPostOrder(t); break;
      case ConstK: break;
      case IdK:   TypeCheckIdentifierPostOrder(t); break;
      default:
        fprintf(listing,"Unknown ExpNode kind\n");
        break;
      }
    }
}


/* Procedure typeCheck performs type checking 
 * by a postorder syntax tree traversal
 */

void TypeCheckMainReturn(void){
  //last in rootSymbolTable ?
  int i;
  symbolTable main_record = SearchSymbolTable(rootSymbolTable,"main");
  int main_line = main_record->lines->num; //first line
  if(!main_record){
    printf("Can not find main function! - there should be main function\n!");
  }else if(main_record && strcmp(main_record->symbolType,"function")!=0 ){
    printf("Can not find main function! - there should be main function\n!");
  }else{
    symbolTable record;
    int line;
    for(i=0;i<SIZE;i++){
      if( (record=rootSymbolTable->table[i]) != NULL){
        while(record!=NULL){
          line = record->lines->num;
          if(line>main_line){
            printf("## line %d - %s\n",line,record->name);
            printf("Line %d : main function should be declared at last of topmost scope\n",main_line);
            return;
          }
          record=record->next;
        }
      }
    }
  }
}
void TypeCheckMainParam(void){
  symbolTable main_record = SearchSymbolTable(rootSymbolTable,"main");
  int main_line = main_record->lines->num; //first line

  if(!main_record)
    return;
  if( main_record->type != Void){
    printf("Line %d : main function\'s return type should be Void\n",main_line);
  }

  if( main_record->attr.params != NULL){
    printf("Line %d : main function should have no parameters\n",main_line);
  }

}
void TypeCheckMain(void){  
  TypeCheckMainReturn();
  TypeCheckMainParam();
}

void typeCheck(TreeNode * syntaxTree){
  currentSymbolTable=rootSymbolTable;
  traverse(syntaxTree,PreOrderCheckNode,PostOrderCheckNode);
  TypeCheckMain();
}
