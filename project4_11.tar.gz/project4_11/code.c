/****************************************************/
/* File: code.c                                     */
/* TM Code emitting utilities                       */
/* implementation for the TINY compiler             */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "code.h"


/* Procedure emitComment prints a comment line
* with comment c in the code file
*/
void emitComment(char * c)
{
  if (TraceCode) fprintf(code, "# %s\n", c);
}

void PushMemoryStack(char *reg){//push reg to stack
  fprintf(code, "addi $sp, $sp, -4\n");
  fprintf(code, "sw %s, 0($sp)\n", reg);
}
void PopMemoryStack(char * reg){//pop to reg from stack
  fprintf(code, "lw %s, 0($sp)\n", reg);
  fprintf(code, "addi $sp, $sp, 4\n");
}
void PopNumberMemoryStack(int i){//pop i*4 bytes
  fprintf(code, "addi $sp, $sp, %d\n", 4 * i);
}

