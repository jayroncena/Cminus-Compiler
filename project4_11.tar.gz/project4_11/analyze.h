/****************************************************/
/* File: analyze.h                                  */
/* Semantic analyzer interface for TINY compiler    */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#ifndef _ANALYZE_H_
#define _ANALYZE_H_

/* Function buildSymtab constructs the symbol 
 * table by preorder traversal of the syntax tree
 */
void buildSymtab(TreeNode *);

/* Procedure typeCheck performs type checking 
 * by a postorder syntax tree traversal
 */
void typeCheck(TreeNode *);

#define SIZE 211
#define SHIFT 4
#define InitStruct(pointer,aliase, str_type) pointer = (aliase) (malloc(sizeof(str_type)));   memset(pointer,0,sizeof(str_type))

typedef struct listOfLineStruct{
  int num;
  struct listOfLineStruct * next;
} *listOfLine;

struct symbolTable;

typedef struct parameterList{
  struct symbolTableStruct * record;
  struct parameterList * next;
}*paramlist;

typedef struct symbolTableStruct
{
  char* symbolType;
  char* name;
  int memoryLocation; 
  ExpType type;
  listOfLine lines;
  union
  {
    int size;
    paramlist params;
  }attr;
  struct symbolTableStruct * next;
}*symbolTable;


typedef struct scopeStruct
{
  int rank;
  int visited;
  int parameterMemory;
  int localMemory;
  int nestedLevel;
  int count;
  symbolTable table[SIZE];
  struct scopeStruct * parent;
  struct scopeStruct * child;
  struct scopeStruct * sibling;
}*symtabScope;

int CheckIdentifier(TreeNode * node);
int CheckIdentifierExpression(TreeNode * node);
int st_lookup3(char* name, symtabScope the_symtab);
symtabScope search_all_symtab4(char* name, symtabScope the_symtab);
symbolTable st_lookup(char* name);
symbolTable st_lookup2(char* name, symtabScope the_symtab);
#endif
