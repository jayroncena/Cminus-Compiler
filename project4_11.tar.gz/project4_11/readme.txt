COMPILING AND EXECUTION:
1. type "make" and press enter from the command line.
2. type "./project4_11 test1.c" and press enter.

MAKE CLEAN:
1. type "make clean"

