/****************************************************/
/* File: code.h                                     */
/* Code emitting utilities for the TINY compiler    */
/* and interface to the TM machine                  */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#ifndef _CODE_H_
#define _CODE_H_


/* code emitting utilities */

/* Procedure emitComment prints a comment line
* with comment c in the code file
*/
void emitComment(char * c);


void PushMemoryStack(char *reg);
void PopMemoryStack(char * reg);
void PopNumberMemoryStack(int i);
#endif
