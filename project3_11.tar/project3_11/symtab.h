/****************************************************/
/* File: symtab.h                                   */
/* Symbol table interface for the TINY compiler     */
/* (allows only one symbol table)                   */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#ifndef _SYMTAB_H_
#define _SYMTAB_H_

#include "globals.h"

/* SIZE is the size of the hash table */
#define SIZE 211

/* the list of line numbers of the source
 * code in which a variable is referenced
 */
typedef struct listOfLineStruct
   { int lineno;
     struct listOfLineStruct * next;
   } * listOfLine;

typedef struct symbolTableStruct
   { 
   char * name;
     listOfLine lines;
     TreeNode *treeNode;
     int locationInStack ; /* memory location for variable */
     struct symbolTableStruct * next;
   } * symbolTable;

typedef struct scopeStruct
   { char * funcName;
     int nestedLevel;
     struct scopeStruct * parent;
     symbolTable hashTable[SIZE]; /* the hash table */
   } * Scope;


Scope globalScope;

/* Procedure st_insert inserts line numbers and
 * memory locations into the symbol table
 * loc = memory location is inserted only the
 * first time, otherwise ignored
 */
void st_insert( char * name, int lineno, int loc, TreeNode * treeNode );

/* Function st_lookup returns the memory
 * location of a variable or -1 if not found
 */
int st_lookup ( char * name );

/* Procedure printSymTab prints a formatted
 * listing of the symbol table contents
 * to the listing file
 */
void printSymTab(FILE * listing);


//============================
//Project 3
//=============================
int AddLocation( void );

Scope CreateScope(char *funcName);
Scope GetTopOfScopeStack( void );
void PopScopeStack( void );
void PushScopeStack( Scope scope );

symbolTable BucketSymbolTable( char * name );
int AddLineNoToSymboltable(char * name, int lineno);
int CheckTopOfSymbolTable  (char * name);

#endif
