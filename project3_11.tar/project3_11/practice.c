#include <stdio.h>
int main ()

{
int amount, price, pay_six;
float pay_three, pm_three, pm_six;

	printf("enter price: ");
	scanf("%d",&amount);

	price = amount;
	price = (price*105) / 100;
	price = (price * 105)/100;
	pay_six = (price* 105)/100;

	pm_three =(float) amount / 3;
	pm_six = (float)pay_six / 6;
	printf("----------------output--------------------\n");
	printf("Month           :          3             6\n");
	printf("Payment         :          %d           %d\n",amount, pay_six);
	printf("------------------------------------------\n");
	printf("Pay/Month       :          %.2f       %.2f\n",pm_three, pm_six);

	return 0;


}
