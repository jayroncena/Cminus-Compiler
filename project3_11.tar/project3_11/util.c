/****************************************************/
/* File: util.c                                     */
/* Utility function implementation                  */
/* for the TINY compiler                            */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "util.h"

/* Procedure printToken prints a token 
 * and its lexeme to the listing file
 */
void printToken( TokenType token, const char* tokenString )
{ switch (token)
  { 
	  case IF: fprintf(listing, "\tIF\t\tif\n");
	  	break;
	  case ELSE: fprintf(listing, "\tELSE\t\telse\n");
	  	break;
	  case INT: fprintf(listing, "\tINT\t\tint\n");
		break;
	  case ID: fprintf(listing," ID: %s\n",tokenString);
      	  	break;
	  case NUM:fprintf(listing, "NUM\t\t%s\n",tokenString);
      	  	break;
	  case ASSIGN: fprintf(listing, " =\n");
	  	break;
	  case EQ: fprintf(listing, " ==\n");
	  	break;
	  case LT: fprintf(listing, " <\n");
	  	break;
	  case PLUS: fprintf(listing, " +\n");
		break;
	  case MINUS: fprintf(listing, " -\n");
		break;
	  case TIMES: fprintf(listing, " *\n");
		break;
	  case OVER: fprintf(listing, " /\n");
		break;
	  case LPAREN: fprintf(listing, " (\n");
		break;
	  case RPAREN: fprintf(listing, " )\n");
		break;
	  case SEMI: fprintf(listing, " ;\n");
		break;
	  case LEFTBRACE: fprintf(listing, " {\n");
		break;
	  case RIGHTBRACE: fprintf(listing, " }\n");
		break;
	  case LEFTBRACKET: fprintf(listing, " [\n");
		break;
	  case RIGHTBRACKET: fprintf(listing, " ]\n");
		break;
	  case RETURN: fprintf(listing, " return\n");
		break;
	  case VOID: fprintf(listing, " void\n");
		break;
	  case WHILE: fprintf(listing, " while\n");
		break;
	  case COMMA: fprintf(listing, " ,\n");
		break;
	  case LESSTHANEQUAL: fprintf(listing, " <=\n");
		break;
	  case GREATERTHAN: fprintf(listing, " >\n");
		break;
	  case GREATERTHANEQUAL: fprintf(listing, " >=\n");
		break;
	  case NOTEQUAL : fprintf(listing, " !=\n");	
		break;
	  case ENDFILE: fprintf(listing, " EOF\n");
		break;
	  case ERROR:fprintf(listing,"\tERROR:\t\t%s\n",tokenString);
		break;
	  default: /* should never happen */
		fprintf(listing,"\tERROR\t%d\n",token);
  }
}

/* Function newStmtNode creates a new statement
 * node for syntax tree construction
 */
TreeNode * newStmtNode(StmtKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
    t->sibling = NULL;
    t->nodekind = StmtK;
    t->kind.statement = kind;
    t->lineno = lineno;
  }
  return t;
}

/* Function newExpNode creates a new expression 
 * node for syntax tree construction
 */
TreeNode * newExpNode(ExpKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
    t->sibling = NULL;
    t->nodekind = ExpK;
    t->kind.expression = kind;
    t->lineno = lineno;
    t->type = Void;
  }
  return t;
}

/* Function copyString allocates and makes a new
 * copy of an existing string
 */
char * copyString(char * s)
{ int n;
  char * t;
  if (s==NULL) return NULL;
  n = strlen(s)+1;
  t = malloc(n);
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else strcpy(t,s);
  return t;
}

/* Variable indentno is used by printTree to
 * store current number of spaces to indent
 */
static int indentno = 0;

/* macros to increase/decrease indentation */
#define INDENT indentno+=2
#define UNINDENT indentno-=2

/* printSpaces indents by printing spaces */
static void printSpaces(void)
{ int i;
  for (i=0;i<indentno;i++)
    fprintf(listing," ");
}

/* procedure printTree prints a syntax tree to the 
 * listing file using indentation to indicate subtrees
 */
void printTree( TreeNode * tree )
{ 
int i;
  INDENT;
  while (tree != NULL) {
    printSpaces();
    //=============================================
    //		Project 2
    //=============================================
    if (tree->nodekind==StmtK)
    { switch (tree->kind.statement) {
        case IfK:
          fprintf(listing,"If\n");
          break;
	case CompK:
	  fprintf(listing,"Compound Statement\n");
	  break;
	case IterK:
	  fprintf(listing,"Repeat\n");
	  break;
	case RetK:
	  fprintf(listing,"Return\n");
	  break;
        default:
          fprintf(listing,"Unknown ExpNode kind\n");
          break;
      }
    }

    else if (tree->nodekind==DeclK)
    { switch (tree->kind.declaration) 
	{
        case VariableK:
          fprintf(listing,"Variable Declaration \n");
          break;
	case FunctionK:
          fprintf(listing,"Function Declaration: \n");
          break;
        case ArrayVarK:
          fprintf(listing,
                  "Var Dec(following const:array length): %s %d\n",
                  tree->attr.arr.name,
                  tree->attr.arr.size);
          break;
        default:
          fprintf(listing,"Unknown DeclNode kind\n");
          break;
      }
    }
	
    else if (tree->nodekind==ParamK)
    { switch (tree->kind.param) {
        case ArrayParameterK:
          fprintf(listing,"Array Parameter: %s\n",tree->attr.name);
          break;
        case NonArrayParameterK:
          //fprintf(listing,"Parameter: %s\n",tree->attr.name);
          fprintf(listing,"Parameter: \n");
          break;
        default:
          fprintf(listing,"Unknown ParamNode kind\n");
          break;
      }
    }
    else if (tree->nodekind==TypeK)
    { switch (tree->kind.type) {
        case TypeNameK:
          fprintf(listing,"Type: ");
          switch (tree->attr.type) {
            case INT:
              fprintf(listing,"int\n");
	      //fprintf(listing,"Id: %s\n",tree->attr.name);
              break;
            case VOID:
              fprintf(listing,"void\n");
          }
          break;
        default:
          fprintf(listing,"Unknown TypeNode kind\n");
          break;
      }
    }
	
    else if (tree->nodekind==ExpK)
    { switch (tree->kind.expression) {
        case OpK:
          fprintf(listing,"Op: ");
          printToken(tree->attr.op,"\0");
          break;
        case ConstK:
          fprintf(listing,"Const: %d\n",tree->attr.val);
          break;
        case IdK:
          fprintf(listing,"Id: %s\n",tree->attr.name);
          break;
	case AssignK:
	  fprintf(listing,"Assign to: ");
	  break;
	case ArrIdK:
	  fprintf(listing,"Array Id: ");
	  break;
	case CallK:
	  fprintf(listing,"Call(Parameters are) : %s\n", tree->attr.name);
	  break;
        default:
          fprintf(listing,"Unknown ExpNode kind\n");
          break;
      }
    }
    else fprintf(listing,"Unknown ExpNode kind\n");
    for (i=0;i<MAXCHILDREN;i++)
         printTree(tree->child[i]);
    tree = tree->sibling;
  }
  UNINDENT;
}

TreeNode * newDeclNode(DeclarationKind kind)
{
	TreeNode *t = (TreeNode *) malloc(sizeof(TreeNode));
	int j;

	if(t != NULL)
	{
		for(j = 0; j < MAXCHILDREN ; j++)
			t->child[j] = NULL;

	t->lineno = lineno;
	t->kind.declaration = kind;
	t->nodekind = DeclK;
	t->sibling = NULL;
	}
	else
		fprintf(listing, "Insufficient memory at line %d\n", lineno);

	return t;

}

TreeNode * newParamNode(ParameterKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
    t->sibling = NULL;
    t->nodekind = ParamK;
    t->kind.param = kind;
    t->lineno = lineno;
  }
  return t;
}

TreeNode * newTypeNode(TypeKind kind)
{ TreeNode * t = (TreeNode *) malloc(sizeof(TreeNode));
  int i;
  if (t==NULL)
    fprintf(listing,"Out of memory error at line %d\n",lineno);
  else {
    for (i=0;i<MAXCHILDREN;i++) t->child[i] = NULL;
    t->sibling = NULL;
    t->nodekind = TypeK;
    t->kind.type = kind;
    t->lineno = lineno;
  }
  return t;
}	
