/****************************************************/
/* File: analyze.c                                  */
/* Semantic analyzer implementation                 */
/* for the TINY compiler                            */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "globals.h"
#include "symtab.h"
#include "analyze.h"
#include "util.h"

static char * funcName;
static int preserveLastScope = FALSE;

/* counter for variable memory locations */

/* Procedure traverse is a generic recursive
 * syntax tree traversal routine:
 * it applies preProc in preorder and postProc
 * in postorder to tree pointed to by t
 */
static void traverse( TreeNode * t,
               void (* preProc) (TreeNode *),
               void (* postProc) (TreeNode *) )
{ if (t != NULL)
  { preProc(t);
    { int i;
      for (i=0; i < MAXCHILDREN; i++)
        traverse(t->child[i],preProc,postProc);
    }
    postProc(t);
    traverse(t->sibling,preProc,postProc);
  }
}

static void insertIOFunc(void)
{ TreeNode *func;
  TreeNode *typeSpec;
  TreeNode *param;
  TreeNode *compStmt;

  func = newDeclNode(FunctionK);

  typeSpec = newTypeNode(FunctionK);
  typeSpec->attr.type = INT;
  func->type = Integer;

  compStmt = newStmtNode(CompK);
  compStmt->child[0] = NULL;      
  compStmt->child[1] = NULL;     

  func->lineno = 0;
  func->attr.name = "input";
  func->child[0] = typeSpec;
  func->child[1] = NULL;         
  func->child[2] = compStmt;


  func = newDeclNode(FunctionK);

  typeSpec = newTypeNode(FunctionK);
  typeSpec->attr.type = VOID;
  func->type = Void;

  param = newParamNode(NonArrayParameterK);
  param->attr.name = "arg";
  param->child[0] = newTypeNode(FunctionK);
  param->child[0]->attr.type = INT;

  compStmt = newStmtNode(CompK);
  compStmt->child[0] = NULL;      
  compStmt->child[1] = NULL;     

  func->lineno = 0;
  func->attr.name = "output";
  func->child[0] = typeSpec;
  func->child[1] = param;
  func->child[2] = compStmt;


}

/* nullProc is a do-nothing procedure to
 * generate preorder-only or postorder-only
 * traversals from traverse
 */
static void nullProc(TreeNode * t)
{ if (t==NULL) return;
  else return;
}

static void symbolError(TreeNode * t, char * message)
{ fprintf(listing,"Symbol error at line %d: %s\n",t->lineno,message);
  Error = TRUE;
}

/* Procedure insertNode inserts
 * identifiers stored in t into
 * the symbol table
 */
static void insertNode( TreeNode * t)
{ switch (t->nodekind)
  { case StmtK:
      switch (t->kind.statement)
      { case CompK:
          if (preserveLastScope) {
            preserveLastScope = FALSE;
          } else {
            Scope scope = CreateScope(funcName);
            PushScopeStack(scope);
          }
          t->attr.scope = GetTopOfScopeStack();
          break;
        default:
          break;
      }
      break;
    case ExpK:
      switch (t->kind.expression)
      { case IdK:
        case ArrIdK:
        case CallK:
          if (st_lookup(t->attr.name) == -1)
          /* not yet in table, error */
            symbolError(t, "The symbol was not declared");
          else
          /* already in table, so ignore location,
             add line number of use only */
            AddLineNoToSymboltable(t->attr.name,t->lineno);
          break;
        default:
          break;
      }
      break;
    case DeclK:
      switch (t->kind.declaration)
      { case FunctionK:
          funcName = t->attr.name;
          if (CheckTopOfSymbolTable (funcName) >= 0) {
            symbolError(t,"Function has been declared already");
            break;
          }
          st_insert(funcName,t->lineno,AddLocation(),t);
          PushScopeStack(CreateScope(funcName));
          preserveLastScope = TRUE;
          switch (t->child[0]->attr.type)
          { case INT:
              t->type = Integer;
              break;
            case VOID:
            default:
              t->type = Void;
              break;
          }
          break;
        case VariableK:
        case ArrayVarK:
          { char *name;

            if (t->child[0]->attr.type == VOID) {
              symbolError(t,"Variable expects non-void type");
              break;
            }

            if (t->kind.declaration == VariableK) {
              name = t->attr.name;
              t->type = Integer;
            } else {
              name = t->attr.arr.name;
              t->type = IntegerArray;
            }

            if (CheckTopOfSymbolTable (name) < 0)
              st_insert(name,t->lineno,AddLocation(),t);
            else
              symbolError(t,"Symbol already declared for current scope");
          }
          break;
        default:
          break;
      }
      break;
    case ParamK:
      if (t->child[0]->attr.type == VOID)
        symbolError(t->child[0],"Void type parameter is not allowed");
      if (st_lookup(t->attr.name) == -1) {
        st_insert(t->attr.name,t->lineno,AddLocation(),t);
        if (t->kind.param == NonArrayParameterK)
          t->type = Integer;
        else
        symbolError(t,"Symbol already declared for current scope");
      }
      break;
    default:
      break;
  }
}

static void afterInsertNode( TreeNode * t )
{ switch (t->nodekind)
  { case StmtK:
      switch (t->kind.statement)
      { case CompK:
          PopScopeStack();
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}

/* Function buildSymtab constructs the symbol
 * table by preorder traversal of the syntax tree
 */
void buildSymtab(TreeNode * syntaxTree)
{ globalScope = CreateScope(NULL);
  PushScopeStack(globalScope);
  insertIOFunc();
  traverse(syntaxTree,insertNode,afterInsertNode);
  PopScopeStack();
  if (TraceAnalyze)
  { fprintf(listing,"\nSymbol table:\n\n");
    printSymTab(listing);
  }
}

static void typeError(TreeNode * t, char * message)
{ fprintf(listing,"Type error at line %d: %s\n",t->lineno,message);
  Error = TRUE;
}

static void beforeCheckNode(TreeNode * t)
{ switch (t->nodekind)
  { case DeclK:
      switch (t->kind.declaration)
      { case FunctionK:
          funcName = t->attr.name;
          break;
        default:
          break;
      }
      break;
    case StmtK:
      switch (t->kind.statement)
      { case CompK:
          PushScopeStack(t->attr.scope);
          break;
        default:
          break;
      }
    default:
      break;
  }
}

/* Procedure checkNode performs
 * type checking at a single tree node
 */
static void checkNode(TreeNode * t)
{ switch (t->nodekind)
  { case StmtK:
      switch (t->kind.statement)
      { case CompK:
          PopScopeStack();
          break;
        case IterK:
          if (t->child[0]->type == Void)
          /* while test should be void function call */
            typeError(t->child[0],"Condition for while has void value");
          break;
        case RetK:
          { const TreeNode * funcDecl =
                BucketSymbolTable(funcName)->treeNode;
            const ExpType funcType = funcDecl->type;
            const TreeNode * expr = t->child[0];

            if (funcType == Void &&
                (expr != NULL && expr->type != Void)) {
              typeError(t,"Expects no return value");
              //ValueReturned = TRUE;
            } else if (funcType == Integer &&
                (expr == NULL || expr->type == Void)) {
              typeError(t,"Expects return value");
            }
          }
          break;
        default:
          break;
      }
      break;
    case ExpK:
      switch (t->kind.expression)
      { 
	  case OpK:
          { ExpType leftType, rightType;
            TokenType op;

            leftType = t->child[0]->type;
            rightType = t->child[1]->type;
            op = t->attr.op;

            if (leftType == Void ||
                rightType == Void)
              typeError(t,"2 operands must have non-void type");
            else if (leftType == IntegerArray &&
                rightType == IntegerArray)
              typeError(t,"Both operands must not be both array");
            else if (op == MINUS &&
                leftType == Integer &&
                rightType == IntegerArray)
              typeError(t,"Invalid operands to binary expression");
            else if ((op == TIMES || op == OVER) &&
                (leftType == IntegerArray ||
                 rightType == IntegerArray))
              typeError(t,"Invalid operands to binary expression");
            else {
              t->type = Integer;
            }
          }
          break;
	  case AssignK:
          if (t->child[0]->type == IntegerArray)
          /* no value can be assigned to array variable */
            typeError(t->child[0],"array variable assignment");
          else if (t->child[1]->type == Void)
          /* r-value cannot have void type */
            typeError(t->child[0],"void value assignment");
          else
            t->type = t->child[0]->type;
          break;
        case ConstK:
          t->type = Integer;
          break;
        case ArrIdK:
          { 
		  const char *symbolName = t->attr.name;
            const symbolTable bucket =
                BucketSymbolTable(symbolName);
            TreeNode *symbolDecl = NULL;

            if (bucket == NULL)
              break;
            symbolDecl = bucket->treeNode;

            if (t->kind.expression == ArrIdK) {
              if (symbolDecl->kind.declaration != ArrayVarK &&
                  symbolDecl->kind.param != ArrayParameterK)
                typeError(t,"expected array symbol");
              else if (t->child[0]->type != Integer)
                typeError(t,"index expression should have integer type");
              else
                t->type = Integer;
            } else {
              t->type = symbolDecl->type;
            }
          }
          break;
        case CallK:
          { const char *callingFuncName = t->attr.name;
            const TreeNode * funcDecl =
                BucketSymbolTable(callingFuncName)->treeNode;
            TreeNode *arg;
            TreeNode *param;

            if (funcDecl == NULL)
              break;

            arg = t->child[0];
            param = funcDecl->child[1];

            if (funcDecl->kind.declaration != FunctionK)
            { typeError(t,"expected function symbol");
              break;
            }

            while (arg != NULL)
            { if (param == NULL)
                typeError(arg,"Wrong number of parameters");
              else if (arg->type == Void)
                typeError(arg,"Void value cannot be passed as an argument");
              else {  // no problem!
                arg = arg->sibling;
                param = param->sibling;
                continue;
              }
              /* any problem */
              break;
            }

            if (arg == NULL && param != NULL)
              typeError(t->child[0],"Wrong number of parameters");

            t->type = funcDecl->type;
          }
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}

/* Procedure typeCheck performs type checking
 * by a postorder syntax tree traversal
 */
void typeCheck(TreeNode * syntaxTree)
{ 
	PushScopeStack(globalScope);
	traverse(syntaxTree,beforeCheckNode,checkNode);
	PopScopeStack();
}
