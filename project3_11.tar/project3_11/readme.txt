yacc 입력 파일: project2_20141535/tiny.y
test 파일1: project2_20141535/errorfree.tny
test 파일2: project1_20141535/error.tny

COMPILING AND EXECUTION:
1. type "make" and press enter from the command line.
2. type "./project3_3 test1.tny" and press enter.

MAKE CLEAN:
1. type "make clean"

