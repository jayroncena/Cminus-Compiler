/****************************************************/
/* File: symtab.c                                   */
/* Symbol table implementation for the TINY compiler*/
/* (allows only one symbol table)                   */
/* Symbol table is implemented as a chained         */
/* hash table                                       */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "symtab.h"


/* SHIFT is the power of two used as multiplier
   in hash function  */
#define SHIFT 4

/* the hash function */
static int hash ( char * key )
{ int j = 0;
  int i = 0;
  while (key[i] != '\0')
  { j = ((j << SHIFT) + key[i]) % SIZE;
    ++i;
  }
  return j;
}

static int numberScopeStack = 0;
static int location[1000];
static int numberScope = 0;
static Scope scopes[1000];
static Scope scopeStack[1000];


Scope GetTopOfScopeStack( void )
{ return scopeStack[numberScopeStack - 1];
}

void PopScopeStack( void )
{
  --numberScopeStack;
}

int AddLocation( void )
{
  return location[numberScopeStack - 1]++;
}

void PushScopeStack( Scope scope )
{ scopeStack[numberScopeStack] = scope;
  location[numberScopeStack++] = 0;
}

Scope CreateScope(char *funcName)
{ Scope newScope;

  newScope = (Scope) malloc(sizeof(struct scopeStruct));
  newScope->funcName = funcName;
  newScope->nestedLevel = numberScopeStack;
  newScope->parent = GetTopOfScopeStack();

  scopes[numberScope++] = newScope;

  return newScope;
}

symbolTable BucketSymbolTable( char * name )
{ int h = hash(name);
  Scope sc = GetTopOfScopeStack();
  while(sc) {
    symbolTable l = sc->hashTable[h];
    while ((l != NULL) && (strcmp(name,l->name) != 0))
      l = l->next;
    if (l != NULL) return l;
    sc = sc->parent;
  }
  return NULL;
}


/* Procedure st_insert inserts line numbers and
 * memory locations into the symbol table
 * loc = memory location is inserted only the
 * first time, otherwise ignored
 */
void st_insert( char * name, int lineno, int loc, TreeNode * treeNode )
{ int h = hash(name);
  Scope top = GetTopOfScopeStack();
  symbolTable l =  top->hashTable[h];
  while ((l != NULL) && (strcmp(name,l->name) != 0))
    l = l->next;
  if (l == NULL) /* variable not yet in table */
  { l = (symbolTable) malloc(sizeof(struct symbolTableStruct));
    l->name = name;
    l->treeNode = treeNode;
    l->lines = (listOfLine) malloc(sizeof(struct listOfLineStruct));
    l->lines->lineno = lineno;
    l->locationInStack = loc;
    l->lines->next = NULL;
    l->next = top->hashTable[h];
    top->hashTable[h] = l; }
  else /* found in table, so just add line number */
  { // ERROR!
  }
} /* st_insert */

/* Function st_lookup returns the memory
 * location of a variable or -1 if not found
 */
int st_lookup ( char * name )
{ symbolTable l = BucketSymbolTable(name);
  if (l != NULL) return l->locationInStack;
  return -1;
}

int CheckTopOfSymbolTable  (char * name)
{ int h = hash(name);
  Scope sc = GetTopOfScopeStack();
  while(sc) {
    symbolTable l = sc->hashTable[h];
    while ((l != NULL) && (strcmp(name,l->name) != 0))
      l = l->next;
    if (l != NULL) return l->locationInStack;
    break;
  }
  return -1;
}

int AddLineNoToSymboltable(char * name, int lineno)
{ symbolTable l = BucketSymbolTable(name);
  listOfLine ll = l->lines;
  while (ll->next != NULL) ll = ll->next;
  ll->next = (listOfLine) malloc(sizeof(struct listOfLineStruct));
  ll->next->lineno = lineno;
  ll->next->next = NULL;
}

void printSymTabRows(symbolTable *hashTable, FILE *listing, Scope scope) 
{
  int j;

  for (j=0;j<SIZE;++j)
  { 

	  if (hashTable[j] != NULL)
	  { 
		  symbolTable l = hashTable[j];
		  TreeNode *node = l->treeNode;
		  
		  while (l != NULL)
		  {
			  listOfLine t = l->lines;
			  fprintf(listing,"%-14s ",l->name);
			  fprintf(listing,"   %d    0\t",scope->nestedLevel);
			  switch (node->nodekind)
			  {
				  case DeclK:
					  switch (node->kind.declaration) 
					  {
						  case FunctionK:
							  fprintf(listing, "TRUE      ");
							  break;
						  case VariableK:
							  fprintf(listing, "FALSE     ");
							  break;
						  case ArrayVarK:
							  //fprintf(listing, "Array Var.");
							  fprintf(listing, "FALSE     array(%d)    ", node->attr.val);
							  break;
						  default:
							  break;
					  }
					  break;
				  case ParamK:
					  switch (node->kind.param) 
					  {
						  case NonArrayParameterK:
							  fprintf(listing, "Variable  ");
							  break;
						  case ArrayParameterK:
							  fprintf(listing, "FALSE     ");
							  break;
						  default:
							  break;
					  }
					  break;
				  default:
					  break;
			  }

			  switch (node->type)
			  {
				  case Void:
					  if (node->nodekind == DeclK)
						  fprintf(listing, "Void         ");
					  else if(node->nodekind == ParamK && node->kind.param == ArrayParameterK)
						  fprintf(listing, "array(param) ");
					  else
						  fprintf(listing, "(param)      ");
					  break;
				  case Integer:
					  fprintf(listing, "int          ");
					  break;
				  case Boolean:
					  fprintf(listing, "Boolean      ");
					  break;
				  default:
					  break;
			  }
			  while (t != NULL)
			  { 
				  fprintf(listing,"%4d ",t->lineno);
				  t = t->next;
			  }
			  fprintf(listing,"\n");
			  l = l->next;
		  }
	  }
  }
}

/* Procedure printSymTab prints a formatted
 * listing of the symbol table contents
 * to the listing file
 */
void printSymTab(FILE * listing)
{ int i;

  for (i = 0; i < numberScope; ++i) {
    Scope scope = scopes[i];
    symbolTable * hashTable = scope->hashTable;

    fprintf(listing,"Variable Name   Scope  Location  IsFunc  Type(size)    Line Numbers\n");
    fprintf(listing,"----------------------------------------------------------------\n");

    printSymTabRows(hashTable, listing,scope);

    fputc('\n', listing);
  }
} /* printSymTab */
