
lex 입력 파일: project1_20141535/tiny.l
test 파일1: project1_20141535/test1.tny
test 파일2: project1_20141535/test2.tny

